from flask_login import UserMixin

class User(UserMixin):
    def __init__(self, username, password, is_admin=False, roles=None):
        self.username = username
        self.password = password
        self.is_admin = is_admin
        self.roles = roles or []

    def get_id(self):
        return self.username

    @staticmethod
    def get(username):
        from config import users
        user = users.get(username)
        if user:
            return User(username, user['password'], user['is_admin'], user.get('roles', []))
        return None
